import pandas as pd
import pickle
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder

def train_and_dump_model(file_path):
    
    df = pd.read_csv(file_path)
    df = df.fillna('unk')

    label_encoders = {}
    for column in df.columns:
        if df[column].dtype == 'object':
            le = LabelEncoder()
            df[column] = le.fit_transform(df[column])
            label_encoders[column] = le
    print("label_encoders",label_encoders)

    X = df[['intent', 'attentionphrase', 'entityname1', 'entityname2']].values
    y = df['class'].values

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    clf = DecisionTreeClassifier(random_state=42)
    clf.fit(X_train, y_train)

    with open('decision_tree_model.pkl', 'wb') as model_file:
        pickle.dump(clf, model_file)

    with open('label_encoders.pkl', 'wb') as le_file:
        pickle.dump(label_encoders, le_file)

def load_model_and_encoders(model_path='decision_tree_model.pkl', encoders_path='label_encoders.pkl'):

    with open(model_path, 'rb') as model_file:
        clf = pickle.load(model_file)

    with open(encoders_path, 'rb') as le_file:
        label_encoders = pickle.load(le_file)

    return clf, label_encoders

def predict(prediction, clf, label_encoders):
    labels_set = {label for le in label_encoders.values() for label in le.classes_}
    
    """labels = {column: list(le.classes_) for column, le in label_encoders.items()}
    #print(labels)
    from itertools import chain
    labels_set = set(chain.from_iterable(labels.values()))
    print(labels_set)"""

    ignore = {'Caller', 'Callee'}
 
    inputs = {
        'intent': prediction['intent']['name'],
        'attentionphrase': 'N',
        'entityname1': 'unk',
        'entityname2': 'unk'
    }
    count = 0

    for entity in prediction['entities']:
        if entity['entity_name'] == 'AttentionPhrase':
            inputs['attentionphrase'] = 'Y'
        elif entity['entity_name'] in labels_set and entity['entity_name'] not in ignore:
            if count < 2:
                inputs['entityname%s' % (count + 1)] = entity['entity_name']
                count += 1

    inputs_encoded = [label_encoders[key].transform([value])[0] for key, value in inputs.items()]
 
    proba = clf.predict_proba([inputs_encoded])
    
    index = proba.argmax()

    return {
        'name': label_encoders['class'].inverse_transform([index])[0],
        'confidence': round(float(proba[0][index]), 3)
        }


if __name__ == '__main__':
    train_and_dump_model("SmartShield_Action_data.csv") #use this function for training
    
    prediction = {
        "entities": [
                {
                    "confidence": 0.987,
                    "end_index": 77,
                    "entity_name": "FinanceInstitutions",
                    "entity_value": "party hall",
                    "start_index": 67,
                    "userInput": "party hall"
                },
                {
                    "confidence": 0.987,
                    "end_index": 77,
                    "entity_name": "FinanceEntity",
                    "entity_value": "party hall",
                    "start_index": 67,
                    "userInput": "party hall"
                }
        ],
        "intent": {
            "confidence": 0.995,
            "name": "Finance"
        }
    }
    
    #uncomment below for prediction
    # clf, label_encoders = load_model_and_encoders()
    # predicted_class = predict(prediction, clf, label_encoders)
    # print(predicted_class)